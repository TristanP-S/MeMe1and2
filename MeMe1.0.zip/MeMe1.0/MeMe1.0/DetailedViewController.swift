//
//  DetailedViewController.swift
//  MeMe1.0
//
//  Created by Tristan Pudell-Spatscheck on 3/7/19.
//  Copyright © 2019 TAPS. All rights reserved.
//
import UIKit
import Foundation
class DetailedViewController: UIViewController {
    @IBOutlet weak var memePic: UIImageView!
    //impots meme index
    var index:  Int!
    //imports the memes to this class
    var memes: [Meme]! {
        return (UIApplication.shared.delegate as! AppDelegate).memes
    }
    //returns back to table/grid view
    @IBAction func sentMemes(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    //does meme editting stuff
    @IBAction func editTapped(_ sender: Any) {
        let vc =  UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "photoEdit") as! ViewController
        vc.index = index
        vc.editting = true
        present(vc, animated: true)
    }
    //sets image of DetailedViewController
    override func viewDidLoad() {
        super.viewDidLoad()
        let meme = memes[index]
        memePic.image = meme.meme
    }
    
}
