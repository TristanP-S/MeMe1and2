//
//  Meme.swift
//  MeMe1.0
//
//  Created by Tristan Pudell-Spatscheck on 3/4/19.
//  Copyright © 2019 TAPS. All rights reserved.
//
//THIS IS JUST THE MEME STRUCT
import Foundation
import UIKit
struct Meme{
    var topText: String!
    var bottomText: String!
    var image: UIImage!
    var meme: UIImage!
}

