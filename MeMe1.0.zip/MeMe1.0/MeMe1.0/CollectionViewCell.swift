//
//  CollectionViewCell.swift
//  MeMe1.0
//
//  Created by Tristan Pudell-Spatscheck on 3/7/19.
//  Copyright © 2019 TAPS. All rights reserved.
//
import UIKit
import Foundation
class CollectionViewCell: UICollectionViewCell{
    @IBOutlet weak var memePic: UIImageView!
    
}
